import six
six.add_move(six.MovedModule('mox', 'mox', 'mox3.mox'))
